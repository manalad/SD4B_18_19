﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab3_Alberca
{
    public partial class Form1 : Form
    {
        Int32 a = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            txt1.Text = txt1.Text + "2";
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            txt1.Text = txt1.Text + "1";
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            txt1.Text = txt1.Text + "3";
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            txt1.Text = txt1.Text + "4";
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            txt1.Text = txt1.Text + "5";
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            txt1.Text = txt1.Text + "6";
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            txt1.Text = txt1.Text + "7";
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            txt1.Text = txt1.Text + "8";
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            txt1.Text = txt1.Text + "9";
        }

        private void btn0_Click(object sender, EventArgs e)
        {
            txt1.Text = txt1.Text + "0";
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            txt1.Text = " ";
            DeclareVariable.total1 = 0;
            DeclareVariable.total2 = 0;
        }

        private void btnequal_Click(object sender, EventArgs e)
        {
            if (DeclareVariable.plusButtonClicked == true)
            {
                DeclareVariable.total2 = System.Convert.ToDouble(txt1.Text);
                DeclareVariable.total2 = DeclareVariable.total1 + DeclareVariable.total2;
                txt1.Text = System.Convert.ToString(DeclareVariable.total2);
                DeclareVariable.total1 = 0;
                DeclareVariable.total2 = 0;
                DeclareVariable.minusButtonClicked = false;
                DeclareVariable.multiplyButtonClicked = false;
                DeclareVariable.divideButtonClicked = false;
                DeclareVariable.plusButtonClicked = false;
            }
            else if (DeclareVariable.minusButtonClicked == true) {
                DeclareVariable.total2 = System.Convert.ToDouble(txt1.Text);
                DeclareVariable.total2 = DeclareVariable.total1 - DeclareVariable.total2;
                txt1.Text = System.Convert.ToString(DeclareVariable.total2);
                DeclareVariable.total1 = 0;
                DeclareVariable.total2 = 0;
                DeclareVariable.plusButtonClicked = false;
                DeclareVariable.multiplyButtonClicked = false;
                DeclareVariable.divideButtonClicked = false;
                DeclareVariable.minusButtonClicked = false;
            }
            else if (DeclareVariable.multiplyButtonClicked == true)
            {
                DeclareVariable.total2 = System.Convert.ToDouble(txt1.Text);
                DeclareVariable.total2 = DeclareVariable.total1 * DeclareVariable.total2;
                txt1.Text = System.Convert.ToString(DeclareVariable.total2);
                DeclareVariable.total1 = 0;
                DeclareVariable.total2 = 0;
                DeclareVariable.minusButtonClicked = false;
                DeclareVariable.plusButtonClicked = false;
                DeclareVariable.divideButtonClicked = false;
                DeclareVariable.multiplyButtonClicked = false;
            }
            else if (DeclareVariable.divideButtonClicked == true) {
                DeclareVariable.total2 = System.Convert.ToDouble(txt1.Text);
                DeclareVariable.total2 = DeclareVariable.total1 / DeclareVariable.total2;
                txt1.Text = System.Convert.ToString(DeclareVariable.total2);
                DeclareVariable.total1 = 0;
                DeclareVariable.total2 = 0;
                DeclareVariable.plusButtonClicked = false;
                DeclareVariable.minusButtonClicked = false;
                DeclareVariable.multiplyButtonClicked = false;
                DeclareVariable.divideButtonClicked = false;

            }
        }

        private void btnplus_Click(object sender, EventArgs e)
        {
            a = 0;
            DeclareVariable.total1 = System.Convert.ToDouble(txt1.Text);
            DeclareVariable.plusButtonClicked = true;
            txt1.Text = " ";


            DeclareVariable.minusButtonClicked = false;
            DeclareVariable.multiplyButtonClicked = false;
            DeclareVariable.divideButtonClicked = false;
        }

        private void btnmultiply_Click(object sender, EventArgs e)
        {
            a = 0;
            DeclareVariable.total1 = System.Convert.ToDouble(txt1.Text);
            
            DeclareVariable.multiplyButtonClicked = true;
            txt1.Text = " ";

            DeclareVariable.minusButtonClicked = false;
            DeclareVariable.plusButtonClicked = false;
            DeclareVariable.divideButtonClicked = false;
        }

        private void btnminus_Click(object sender, EventArgs e)
        {
            a = 0;
            DeclareVariable.total1 = (System.Convert.ToDouble(txt1.Text));
            DeclareVariable.minusButtonClicked = true;
            txt1.Text = " ";

            DeclareVariable.plusButtonClicked = false;
            DeclareVariable.multiplyButtonClicked = false;
            DeclareVariable.divideButtonClicked = false;
        }

        private void btndivide_Click(object sender, EventArgs e)
        {
            a = 0;
            DeclareVariable.total1 = System.Convert.ToDouble(txt1.Text);
            DeclareVariable.divideButtonClicked = true;
            txt1.Text = " ";

            DeclareVariable.plusButtonClicked = false;
            DeclareVariable.minusButtonClicked = false;
            DeclareVariable.multiplyButtonClicked = false;
        }

        private void btndot_Click(object sender, EventArgs e)
        {
            while (a < 1) {
                txt1.Text = txt1.Text + ".";
                a += 1;

            }
        }
    }
}
