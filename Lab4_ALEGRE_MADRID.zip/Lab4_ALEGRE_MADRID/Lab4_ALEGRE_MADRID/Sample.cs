﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4_ALEGRE_MADRID
{
    class Sample
    {
        public string fname, lname;
        public Sample()
        {
            fname = "Kathlyn";
            lname = "Alegre";
        }
    }
}
