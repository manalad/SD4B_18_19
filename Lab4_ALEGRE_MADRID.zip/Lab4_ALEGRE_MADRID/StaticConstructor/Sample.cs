﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaticConstructor
{
    class Sample
    {
        public string fname, lname;

        static Sample()
        {
            System.Console.WriteLine("Static Constructor");
        }

        public Sample()
        {
            fname = "Judith";
            lname = "Madrid";
        }
    }
}
