﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Average
{
    class Sample
    {
        public double number1, number2, number3, number4, number5;
        public Sample(double a, double b, double c, double d, double e)
        {
            number1 = a;
            number2 = b;
            number3 = c;
            number4 = d;
            number5 = e;
        }
    }
}
