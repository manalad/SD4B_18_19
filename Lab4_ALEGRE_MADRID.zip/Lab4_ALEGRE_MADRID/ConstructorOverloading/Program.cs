﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstructorOverloading
{
    class Program
    {
        static void Main(string[] args)
        {
            Sample s = new Sample();
            Sample s1 = new Sample("Judith", "Madrid");
            Console.WriteLine(s.fname + " " + s.lname);
            Console.WriteLine(s1.fname + " " + s1.lname);
            Console.ReadLine();
        }
    }
}
