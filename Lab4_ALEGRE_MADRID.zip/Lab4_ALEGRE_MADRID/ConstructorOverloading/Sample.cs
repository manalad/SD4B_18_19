﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstructorOverloading
{
    class Sample
    {
        public string fname, lname;
        public Sample()
        {
            fname = "Judith";
            lname = "Madrid";
        }
        public Sample(string j, string m)
        {
            fname = j;
            lname = m;
        }
    }
}
