﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CopyConstructor
{
    class Sample
    {
        public string fname, lname;
        public Sample(string k, string a)

        {
            fname = k;
            lname = a;
        }
        public Sample(Sample s)
        {
            fname = s.fname;
            lname = s.lname;
        }
    }
}
