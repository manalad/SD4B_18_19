﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrivateConstructor
{
    class Sample
    {
        public string fname, lname;
        public Sample(string k, string a)
        {
            fname = k;
            lname = a;
        }
        private Sample()
        {
            System.Console.WriteLine("Private constructor with no paramaeters");
        }
    }
}
