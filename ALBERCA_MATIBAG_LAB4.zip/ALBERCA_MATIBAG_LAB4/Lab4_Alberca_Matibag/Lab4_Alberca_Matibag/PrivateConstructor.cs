﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4_Alberca_Matibag
{
    class PrivateConstructor
    {
        public int Sum, Diff, Pro;
        public string Quo, Rem;
        public PrivateConstructor(int x, int y, int xx, string yy, string zz)
        {
            Sum = x;
            Diff = y;
            Pro = xx;
            Quo = yy;
            Rem = zz;
        }
        private PrivateConstructor()
        {
            System.Console.WriteLine("Private Constructor with no parameters");
        }
    }
}
