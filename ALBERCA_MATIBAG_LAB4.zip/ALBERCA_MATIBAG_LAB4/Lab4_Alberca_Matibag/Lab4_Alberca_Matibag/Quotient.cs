﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4_Alberca_Matibag
{
    class Quotient
    {
        public void QuoDetails()
        {
            try
            {
                DecVar.Quo = Convert.ToString(DecVar.num1 / DecVar.num2);
                
            }
            catch (System.DivideByZeroException ex)
            {
                DecVar.Quo = "Error: " + ex.Message;
                
            }
        }
    }
}
