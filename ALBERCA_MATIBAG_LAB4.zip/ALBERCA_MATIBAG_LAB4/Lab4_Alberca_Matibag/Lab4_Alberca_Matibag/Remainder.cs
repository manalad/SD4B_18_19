﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4_Alberca_Matibag
{
    class Remainder
    {
        public void RemDetails()
        {
            try
            {
                if (DecVar.num1 > DecVar.num2)
                {
                    DecVar.Rem = Convert.ToString(DecVar.num1 % DecVar.num2);
                   
                }
                else
                {
                    DecVar.Rem = "0";
                }

            }
            catch (System.DivideByZeroException ex)
            {
                DecVar.Rem = "Error: " + ex.Message;
                
            }
        }
    }
}
