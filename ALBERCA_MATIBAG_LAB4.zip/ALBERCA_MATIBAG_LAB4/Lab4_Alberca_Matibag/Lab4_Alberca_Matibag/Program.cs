﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4_Alberca_Matibag
{
    class Program
    {
        static void Main(string[] args)
        {
            DecVar dv = new DecVar();
            dv.DevVarDetails();

            Sum s = new Sum();
            s.SumDetails();
            Difference d = new Difference();
            d.DiffDetails();
            Product p = new Product();
            p.ProductDetails();
            Quotient q = new Quotient();
            q.QuoDetails();
            Remainder r = new Remainder();
            r.RemDetails();


            PrivateConstructor privateConst = new PrivateConstructor(DecVar.Sum, DecVar.Diff, DecVar.Pro, DecVar.Quo, DecVar.Rem);
            System.Console.WriteLine("\n\nSum = " + privateConst.Sum);
            System.Console.WriteLine("\n\nDifference = " + privateConst.Diff);
            System.Console.WriteLine("\n\nProduct = " + privateConst.Pro);
            System.Console.WriteLine("\n\nQuotient = " + privateConst.Quo);
            System.Console.WriteLine("\n\nRemainder = " + privateConst.Rem);

            Console.ReadKey();

        }
    }
}
