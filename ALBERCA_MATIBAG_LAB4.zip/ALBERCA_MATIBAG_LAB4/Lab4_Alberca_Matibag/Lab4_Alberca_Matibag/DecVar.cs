﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4_Alberca_Matibag
{
    class DecVar
    {
        public static int num1, num2, Sum, Diff, Pro;
        public static string Quo, Rem;
        public void DevVarDetails() {
            System.Console.WriteLine("Basic Operations \n\n");
            try
            {
                System.Console.Write("Enter the first number: ");
                num1 = System.Convert.ToInt32(System.Console.ReadLine());
                System.Console.Write("Enter second number: ");
                num2 = System.Convert.ToInt32(System.Console.ReadLine());
            }
            catch (System.FormatException)
            {
                System.Console.WriteLine("User Input Invalid!");

            }


        }
    }
}
