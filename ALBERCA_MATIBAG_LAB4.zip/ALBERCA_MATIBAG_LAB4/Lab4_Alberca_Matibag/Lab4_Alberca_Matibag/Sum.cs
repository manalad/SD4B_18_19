﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4_Alberca_Matibag
{
    class Sum
    {
        public void SumDetails()
        {
            DecVar.Sum = DecVar.num1 + DecVar.num2;
            
        }
    }
}
