﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParameterizedConstructors_Alberca_Matibag
{
    class Program
    {
        static void Main(string[] args)
        {
            Sample s = new Sample("Moises","Matibag");
            Console.WriteLine(s.firstname);
            Console.WriteLine(s.lastname);
            Console.ReadLine();

        }
    }
}
