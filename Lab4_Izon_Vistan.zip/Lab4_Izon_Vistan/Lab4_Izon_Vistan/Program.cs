﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4_Izon_Vistan
{
    class Program
    {
        static void Main(string[] args)
        {
            double a, b, c, d, e;
            Console.WriteLine("Enter your first number: ");
            a = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter your second number: ");
            b = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter your third number: ");
            c = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter your fourth number: ");
            d = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter your fifth number: ");
            e = Convert.ToDouble(Console.ReadLine());
            Sample s = new Sample(a, b, c, d, e);
            Console.WriteLine("Average: " + (s.number1 + s.number2 + s.number3 + s.number4 + s.number5)/5);
            Console.ReadLine();
        }
    }
}
