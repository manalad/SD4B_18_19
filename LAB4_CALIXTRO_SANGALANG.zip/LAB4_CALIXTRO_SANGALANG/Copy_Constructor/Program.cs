﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Copy_Constructor
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("***Copy Constractor***" + "\n");

            Sample CConstractor = new Sample("Oseas ", "Calixtro", "Markus ", "Sangalang");
            Sample CConstructor2 = new Sample(CConstractor);

            Console.WriteLine(CConstractor);
            Console.WriteLine("\n" + CConstructor2.Fname1 + "\n\n" + CConstructor2.Lname1);
            Console.WriteLine("\n" + CConstructor2.Fname2 + "\n\n" + CConstructor2.Lname2);

            Console.ReadLine();
        }
    }
}
