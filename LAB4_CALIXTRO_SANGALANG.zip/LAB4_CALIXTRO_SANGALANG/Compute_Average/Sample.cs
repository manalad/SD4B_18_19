﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compute_Average
{
    class Sample
    {
        public double num1, num2, num3, num4, num5, average;
        public Sample(double cnum1, double cnum2, double cnum3, double cnum4, double cnum5)
        {
            num1 = cnum1;
            num2 = cnum2;
            num3 = cnum3;
            num4 = cnum4;
            num5 = cnum5;
            average = (num1 + num2 + num3 + num4 + num5) / 5;

        }
        public Sample(Sample calculateAverage)
        {
            num1 = calculateAverage.num1;
            num2 = calculateAverage.num2;
            num3 = calculateAverage.num3;
            num4 = calculateAverage.num4;
            num5 = calculateAverage.num5;
            average = (num1 + num2 + num3 + num4 + num5) / 5;
        }
    }
}
