﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compute_Average
{
    class Program
    {
        static void Main(string[] args)
        {
            System.Console.WriteLine("Enter 5 Grades:");
            double grade1 = Convert.ToDouble(Console.ReadLine());
            double grade2 = Convert.ToDouble(Console.ReadLine());
            double grade3 = Convert.ToDouble(Console.ReadLine());
            double grade4 = Convert.ToDouble(Console.ReadLine());
            double grade5 = Convert.ToDouble(Console.ReadLine());

            Sample sendVariables = new Sample(grade1, grade2, grade3, grade4, grade5);
            Sample calculateAverage = new Sample(sendVariables);

            System.Console.WriteLine("The Average is {0:0.000}", calculateAverage.average, ".");
            System.Console.ReadLine();
        }
    }
}
