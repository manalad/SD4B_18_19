﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Default_Constructor
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("***Default Constractor***"+"\n");
            Sample DConstractor = new Sample();

            Console.Write(DConstractor.Fname1);
            Console.WriteLine(DConstractor.Lname1);
            Console.Write(DConstractor.Fname2);
            Console.WriteLine(DConstractor.Lname2);

            Console.ReadLine();
        }
    }
}
