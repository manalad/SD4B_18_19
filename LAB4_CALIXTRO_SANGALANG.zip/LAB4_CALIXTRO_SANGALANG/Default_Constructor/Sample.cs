﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Default_Constructor
{
    class Sample
    {
        public string Fname1, Lname1, Fname2, Lname2;
        public Sample()
        {
            Fname1 = "Oseas ";
            Lname1 = "Calixtro";
            Fname2 = "Markus ";
            Lname2 = "Sangalang";
        }
    }
}
