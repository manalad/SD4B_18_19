﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Constructor_Overloading
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("***Constractor Overload***" + "\n");
            Sample COConstructor = new Sample();
            Sample COConstructor2 = new Sample("Oseas ", "Calixtro", "Markus", "Sangalang");

            Console.WriteLine(COConstructor.Fname1 + COConstructor.Lname1);
            Console.WriteLine(COConstructor.Fname2 + COConstructor.Lname2);
            Console.WriteLine(COConstructor2.Fname1 + COConstructor2.Lname1);
            Console.WriteLine(COConstructor2.Fname2 + COConstructor2.Lname2);

            Console.ReadLine();
        }
    }
}
