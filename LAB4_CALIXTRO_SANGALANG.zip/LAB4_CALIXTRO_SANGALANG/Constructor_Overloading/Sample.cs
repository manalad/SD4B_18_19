﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Constructor_Overloading
{
    class Sample
    {
        public string Fname1, Lname1, Fname2, Lname2;
        public Sample()
        {
            Fname1 = "Oseas ";
            Lname1 = "Calixtro";
            Fname2 = "Markus ";
            Lname2 = "Sangalang";
        }
        public Sample(string a, string b, string c, string d)
        {
            Fname1 = a;
            Lname1 = b;
            Fname2 = c;
            Lname2 = d;
        }
    }
}
