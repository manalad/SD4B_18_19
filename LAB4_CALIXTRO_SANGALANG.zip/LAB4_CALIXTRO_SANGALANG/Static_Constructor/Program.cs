﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Static_Constructor
{
    class Program
    {
        static void Main(string[] args)
        {
            Sample SConstructor = new Sample();
            Sample SConstructor2 = new Sample();

            Console.Write(SConstructor.Fname1);
            Console.WriteLine(SConstructor2.Fname1 + SConstructor2.Lname1);
            Console.WriteLine(SConstructor2.Fname2 + SConstructor2.Lname2);

            Console.ReadLine();
        }
    }
}
