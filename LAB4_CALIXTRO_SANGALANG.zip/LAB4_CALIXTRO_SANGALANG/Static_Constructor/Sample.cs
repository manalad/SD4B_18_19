﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Static_Constructor
{
    class Sample
    {
        public string Fname1, Lname1, Fname2, Lname2;
        static Sample()
        {
            Console.WriteLine("***Static Constractor***" + "\n");
        }
        public Sample()
        {
            Fname1 = "Oseas ";
            Lname1 = "Calixtro";
            Fname2 = "Markus ";
            Lname2 = "Sangalang";
        }
    }
}
