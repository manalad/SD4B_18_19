﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Private_Constructor
{
    class Sample
    {
        public string Fname1, Lname1, Fname2, Lname2;
        public Sample(string name1, string name2, string name3, string name4)
        {
            Fname1 = name1;
            Lname1 = name2;
            Fname2 = name3;
            Lname2 = name4;
        }
        private Sample()
        {
            System.Console.WriteLine("Private Constructor with no parameters");
        }
    }
}
