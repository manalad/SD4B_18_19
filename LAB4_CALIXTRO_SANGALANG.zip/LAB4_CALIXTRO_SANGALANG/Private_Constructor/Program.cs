﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Private_Constructor
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("***Private Constractor***" + "\n");
            Sample PConstractor = new Sample("Oseas", "Calixtro", "Markus ", "Sangalang");

            Console.Write(PConstractor.Fname1);
            Console.WriteLine(PConstractor.Lname1);
            Console.Write(PConstractor.Fname2);
            Console.WriteLine(PConstractor.Lname2);

            Console.ReadLine();
        }
    }
}
